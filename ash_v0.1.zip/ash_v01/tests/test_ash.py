import json, os, shutil, tempfile, unittest
from pathlib import Path

from ash import freezeframe as ff
from ash.controller import AshController
from ash.demo import build_script
from ash.models import Decision, utc_now
from ash.state import AgentState, FrameState, IllegalTransition, SystemState


def D(choice): return Decision(choice, "test", utc_now())


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, self.tmp, True)

    def run_to_hold(self, script=None, window=20):
        c = AshController(self.tmp, script or build_script(), window=window)
        while c.agent.has_steps and c.state.agent is AgentState.NORMAL:
            c.agent.step()
        return c


class TestDetection(Base):
    def test_normal_telemetry_no_alert(self):
        c = AshController(self.tmp, [("read_file", "x")] * 10)
        while c.agent.has_steps: c.agent.step()
        self.assertIsNone(c.incident)
        self.assertEqual(c.state.agent, AgentState.NORMAL)

    def test_anomaly_exactly_one_alert_and_hold(self):
        c = self.run_to_hold()
        for _ in range(3): c.agent.step()          # repeats while held
        self.assertEqual(c.canary._n, 1)
        self.assertEqual(c.state.agent, AgentState.HOLD)
        self.assertEqual(c.state.frame, FrameState.SEALED)
        self.assertEqual(c.incident.alert.authority_requested, "none")

    def test_unauthorised_tool_never_executes_and_hold_blocks_tools(self):
        c = self.run_to_hold()
        c.agent.step()                             # allowed tool, but HOLD
        prod = json.loads(c.agent.path.read_text())
        self.assertNotIn("shell_exec", [t["tool"] for t in prod["executed_tools"]])
        self.assertEqual(len(prod["blocked_attempts"]), 2)   # trigger + 1 held step
        self.assertGreater(c.radar.history[-1].seq, c.incident.trigger.seq)  # telemetry continues


class TestStateMachine(unittest.TestCase):
    def test_illegal_transitions(self):
        s = SystemState()
        with self.assertRaises(IllegalTransition): s.resume()
        with self.assertRaises(IllegalTransition): s.begin_capture()
        s.enter_hold("t")
        with self.assertRaises(IllegalTransition): s.resume()      # not sealed
        s.begin_capture(); s.frame_sealed()
        s.resume()
        s.enter_hold("again")                                       # new incident allowed
        self.assertEqual(s.frame, FrameState.NOT_CAPTURED)

    def test_aborted_is_terminal_and_failed_closed_cannot_resume(self):
        s = SystemState(); s.enter_hold("t"); s.begin_capture(); s.capture_failed("x")
        self.assertEqual(s.agent, AgentState.FAILED_CLOSED)
        with self.assertRaises(IllegalTransition): s.resume()
        s.abort()
        with self.assertRaises(IllegalTransition): s.enter_hold("t")


class TestFreezeFrame(Base):
    def test_window_has_trigger_last_and_is_not_padded(self):
        c = self.run_to_hold()
        w = c.incident.frame["fields"]["telemetry_window"]["value"]
        self.assertEqual(w["count"], 20)
        self.assertEqual(w["events"][-1]["seq"], c.incident.trigger.seq)
        c2 = AshController(tempfile.mkdtemp(), [("read_file", "a"), ("shell_exec", "b")])
        self.addCleanup(shutil.rmtree, c2.root, True)
        while c2.agent.has_steps and c2.state.agent is AgentState.NORMAL: c2.agent.step()
        w2 = c2.incident.frame["fields"]["telemetry_window"]["value"]
        self.assertEqual(w2["count"], 3)           # 2 events from step 1 + trigger, nothing invented

    def test_unavailable_fields_marked_not_faked(self):
        f = self.run_to_hold().incident.frame["fields"]
        for k in ("model_version_hash", "agp_state", "memory_state", "cryptographic_provenance"):
            self.assertEqual(f[k]["status"], "unavailable"); self.assertTrue(f[k]["reason"])
            self.assertNotIn("value", f[k])

    def test_hash_verifies_then_fails_after_one_byte_tamper(self):
        c = self.run_to_hold(); s = c.incident.seal
        self.assertTrue(ff.verify(s.frame_dir, s.sha256).ok)
        os.chmod(s.frame_path, 0o644)
        b = bytearray(s.frame_path.read_bytes()); b[10] ^= 1; s.frame_path.write_bytes(bytes(b))
        self.assertFalse(ff.verify(s.frame_dir, s.sha256).ok)

    def test_evidence_files_are_read_only_and_not_overwritten(self):
        c = self.run_to_hold(); s = c.incident.seal
        self.assertEqual(os.stat(s.frame_path).st_mode & 0o222, 0)
        with self.assertRaises(FileExistsError): ff.seal(c.incident.frame, c.evidence_dir, utc_now)

    def test_canonical_unchanged_after_clone_is_modified(self):
        c = self.run_to_hold(); s = c.incident.seal
        before = s.frame_path.read_bytes()
        p = c.make_experiment_clone(); ff.mutate_clone(p)
        self.assertNotEqual((p / "frame.json").read_bytes(), before)
        self.assertEqual(s.frame_path.read_bytes(), before)
        self.assertTrue(ff.verify(s.frame_dir, s.sha256).ok)


class TestDecision(Base):
    def test_resume_ok_re_enables_tools(self):
        c = self.run_to_hold()
        self.assertEqual(c.decide(D("RESUME")).outcome, "RESUMED")
        n = len(c.agent.executed)
        c.agent.step()
        self.assertEqual(len(c.agent.executed), n + 1)

    def test_resume_refused_on_tampered_frame(self):
        c = self.run_to_hold(); s = c.incident.seal
        os.chmod(s.frame_path, 0o644); s.frame_path.write_bytes(s.frame_path.read_bytes() + b" ")
        self.assertEqual(c.decide(D("RESUME")).outcome, "RESUME_REFUSED")
        self.assertEqual(c.state.agent, AgentState.FAILED_CLOSED)
        self.assertFalse(c.state.tools_permitted())

    def test_resume_refused_when_frame_and_manifest_both_forged(self):
        c = self.run_to_hold(); s = c.incident.seal
        os.chmod(s.frame_path, 0o644); os.chmod(s.manifest_path, 0o644)
        s.frame_path.write_bytes(b"{}\n")
        m = json.loads(s.manifest_path.read_bytes()); m["sha256"] = ff.sha256_hex(b"{}\n")
        s.manifest_path.write_bytes(ff.canonical_bytes(m))
        self.assertEqual(c.decide(D("RESUME")).outcome, "RESUME_REFUSED")   # independently held hash

    def test_abort_preserves_evidence_and_deletes_nothing(self):
        c = self.run_to_hold(); s = c.incident.seal
        files_before = sorted(p.name for p in s.frame_dir.iterdir())
        self.assertEqual(c.decide(D("ABORT")).outcome, "ABORTED")
        self.assertFalse(c.agent.running)
        self.assertEqual(sorted(p.name for p in s.frame_dir.iterdir()), files_before)
        self.assertTrue(ff.verify(s.frame_dir, s.sha256).ok)
        self.assertTrue(c.agent.path.exists())

    def test_no_input_stays_in_hold(self):
        c = self.run_to_hold()
        def eof(_): raise EOFError
        self.assertIsNone(c.request_human_decision(input_fn=eof, out=lambda *_: None))
        self.assertEqual(c.state.agent, AgentState.HOLD)

    def test_capture_failure_fails_closed(self):
        c = AshController(self.tmp, build_script())
        c.evidence_dir.rmdir(); c.evidence_dir.write_text("not a dir")   # sabotage
        while c.agent.has_steps and c.state.agent is AgentState.NORMAL: c.agent.step()
        self.assertEqual(c.state.agent, AgentState.FAILED_CLOSED)
        self.assertEqual(c.decide(D("RESUME")).outcome, "RESUME_REFUSED")


class TestRecord(Base):
    def test_record_contains_hash_decision_and_chain_verifies(self):
        c = self.run_to_hold(); c.make_experiment_clone()
        c.decide(D("ABORT")); path, digest = c.finalize()
        text = path.read_text()
        self.assertIn(c.incident.seal.sha256, text)
        self.assertIn("ABORT", text); self.assertIn("ABORTED", text)
        for h in ("Production state", "Canonical evidence", "Experimental state", "immune-memory"):
            self.assertIn(h, text)
        ok, problems = c.records.verify_chain(); self.assertTrue(ok, problems)

    def test_chain_links_and_detects_tampering(self):
        c1 = self.run_to_hold(); c1.decide(D("ABORT")); c1.finalize()
        c2 = AshController(self.tmp, build_script()); 
        while c2.agent.has_steps and c2.state.agent is AgentState.NORMAL: c2.agent.step()
        c2.decide(D("RESUME")); p2, _ = c2.finalize()
        self.assertIn(c1.incident.record_hash, p2.read_text())
        self.assertTrue(c2.records.verify_chain()[0])
        os.chmod(c1.incident.record_path, 0o644)
        c1.incident.record_path.write_text("tampered")
        self.assertFalse(c2.records.verify_chain()[0])

    def test_pending_record_when_no_decision(self):
        c = self.run_to_hold(); path, _ = c.finalize()
        self.assertIn("PENDING", path.read_text())

    def test_untrusted_telemetry_cannot_break_table(self):
        c = AshController(self.tmp, [("shell_exec", "a|b\n## injected `x`")])
        c.agent.step(); c.decide(D("ABORT")); path, _ = c.finalize()
        self.assertNotIn("\n## injected", path.read_text())


if __name__ == "__main__":
    unittest.main()
