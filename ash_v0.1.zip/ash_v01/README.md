# ASH v0.1: Dragon Radar → Canary → HOLD → Freeze-Frame → RESUME/ABORT → Event Record

Python 3 stdlib only (runs in Termux). Deterministic; no AI judge.

    python -m ash.demo                          # interactive: you type r / a / w
    python -m ash.demo --decision abort         # test harness decides (recorded as test-harness)
    python -m ash.demo --clone                  # also make + modify an experimental clone
    python -m ash.demo --tamper --decision resume   # corrupt evidence; RESUME must be refused
    python -m unittest discover -s tests -t .   # 20 tests

## Layout
- `ash/radar.py` Dragon Radar (rule: tool not on allowlist)
- `ash/canary.py` standardised alert (`authority_requested: none`)
- `ash/state.py` agent state and Freeze-Frame state, kept separate
- `ash/freezeframe.py` capture / seal (SHA-256) / verify / clone
- `ash/decision.py` human prompt; no answer = stay in HOLD
- `ash/record.py` Markdown event record + hash chain (`events/chain.txt`)
- `ash/controller.py` thin orchestrator (not in the original proposal)
- `data/production|evidence|experiments|events` = the four state categories, kept apart

## Behaviour decided with DJ + ChatGPT
HOLD blocks tool execution; telemetry keeps flowing. ABORT stops the loop, deletes nothing.
Window = 20 events (configurable), trigger last, never padded. SHA-256 only, unsigned.

## Known limits
- Tamper-evidence, not authenticity. chmod 0444 is a speed bump.
- HOLD lives in memory; a process restart does not restore it.
- The unauthorised call is blocked before it executes (Radar runs on the attempt event).
