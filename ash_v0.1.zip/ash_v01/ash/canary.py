"""Canary: standardised alert mechanism (not the detector)."""
from __future__ import annotations

from .models import CanaryAlert, Finding, utc_now


class Canary:
    def __init__(self, source="dragon-radar", clock=utc_now):
        self.source = source
        self._clock = clock
        self._n = 0

    def emit(self, finding: Finding) -> CanaryAlert:
        self._n += 1
        return CanaryAlert(
            alert_id=f"canary-{self._n:04d}", ts=self._clock(), source=self.source,
            rule_id=finding.rule_id, severity=finding.severity,
            observed=finding.observed, threshold=finding.threshold,
            trigger_seq=finding.trigger_seq, message=finding.message,
        )
