"""Human decision prompt. No answer => no decision => stay in HOLD (fail closed)."""
from __future__ import annotations

from typing import Optional

from .models import Decision, utc_now


def prompt_human(input_fn=input, out=print, max_invalid=3) -> Optional[Decision]:
    out("  [R]esume  [A]bort  [W]ait (stay in HOLD)")
    for _ in range(max_invalid):
        try:
            s = input_fn("  decision> ").strip().lower()
        except EOFError:
            return None
        if s in ("r", "resume"):
            return Decision("RESUME", "human-cli", utc_now())
        if s in ("a", "abort"):
            return Decision("ABORT", "human-cli", utc_now())
        if s in ("w", "wait", ""):
            return None
        out("  please answer r, a or w")
    return None
