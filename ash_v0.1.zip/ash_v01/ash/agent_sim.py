"""Scripted fake agent. Writes its 'production' state to disk."""
from __future__ import annotations

import json
import os
from pathlib import Path

from .models import TelemetryEvent, utc_now


class SimAgent:
    def __init__(self, agent_id, script, production_dir, emit, tools_permitted, clock=utc_now):
        self.agent_id = agent_id
        self.script = list(script)       # [(tool, detail), ...]
        self.pos = 0
        self.running = True
        self._seq = 0
        self._emit = emit
        self._permitted = tools_permitted
        self._clock = clock
        self.executed: list[dict] = []
        self.blocked: list[dict] = []
        self.path = Path(production_dir) / "agent_state.json"
        self._persist()

    @property
    def has_steps(self) -> bool:
        return self.running and self.pos < len(self.script)

    def _event(self, kind, tool, detail, outcome="observed"):
        self._seq += 1
        return TelemetryEvent(self._seq, self._clock(), kind, tool, detail, outcome)

    def _persist(self):
        data = {"agent_id": self.agent_id, "running": self.running,
                "executed_tools": self.executed, "blocked_attempts": self.blocked,
                "updated_at": self._clock()}
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, indent=2, sort_keys=True))
        os.replace(tmp, self.path)

    def step(self):
        """Announce intent (telemetry first), then execute only if tools are permitted."""
        tool, detail = self.script[self.pos]
        self.pos += 1
        attempt = self._event("tool_attempt", tool, detail)
        self._emit(attempt)                      # Radar may trigger HOLD synchronously
        if self._permitted():
            self.executed.append({"seq": attempt.seq, "tool": tool})
            self._persist()
            self._emit(self._event("tool_result", tool, "simulated side effect applied", "executed"))
        else:
            self.blocked.append({"seq": attempt.seq, "tool": tool})
            self._persist()
            self._emit(self._event("tool_result", tool, "not executed: tools blocked", "blocked"))

    def stop(self):
        self.running = False
        self._persist()
