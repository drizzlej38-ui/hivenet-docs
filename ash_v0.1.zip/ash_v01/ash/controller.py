"""Wires Agent -> Radar -> Canary -> HOLD -> Freeze-Frame -> Decision -> Record.
(Not in the original proposal: a thin orchestrator so each piece stays testable.)"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from . import freezeframe as ff
from .agent_sim import SimAgent
from .canary import Canary
from .decision import prompt_human
from .models import (CanaryAlert, Decision, DecisionOutcome, TelemetryEvent,
                     compact_now, utc_now)
from .radar import DragonRadar, ToolAllowlistRule
from .record import RecordWriter
from .state import AgentState, FrameState, IllegalTransition, SystemState

DEFAULT_ALLOWLIST = ("read_file", "search_notes", "summarize", "list_dir")


@dataclass
class Incident:
    incident_id: str
    frame_id: str
    alert: CanaryAlert
    trigger: TelemetryEvent
    frame: Optional[dict] = None
    seal: Optional[ff.SealResult] = None
    capture_error: Optional[str] = None
    suppressed: int = 0
    decisions: list = field(default_factory=list)
    experiment: Optional[dict] = None
    record_path: Optional[Path] = None
    record_hash: Optional[str] = None


class AshController:
    def __init__(self, root, script, *, agent_id="sim-agent-1", allowlist=DEFAULT_ALLOWLIST,
                 window=20, clock=utc_now, log=None):
        self.root = Path(root)
        self.production_dir = self.root / "production"      # original/production state
        self.evidence_dir = self.root / "evidence"          # canonical, sealed
        self.experiments_dir = self.root / "experiments"    # modifiable clones
        self.events_dir = self.root / "events"              # event / immune-memory records
        for d in (self.production_dir, self.evidence_dir, self.experiments_dir, self.events_dir):
            d.mkdir(parents=True, exist_ok=True)
        self.clock, self.window = clock, window
        self.log = log or (lambda stage, msg: None)
        self.agent_id, self.allowlist = agent_id, tuple(allowlist)
        self.state = SystemState(clock)
        self.radar = DragonRadar([ToolAllowlistRule(self.allowlist)])
        self.canary = Canary(clock=clock)
        self.records = RecordWriter(self.events_dir)
        self.agent = SimAgent(agent_id, script, self.production_dir,
                              emit=self.ingest, tools_permitted=self.state.tools_permitted,
                              clock=clock)
        self.incident: Optional[Incident] = None
        self._n = 0

    # ---- detection -> alert -> HOLD -> capture ------------------------
    def ingest(self, event: TelemetryEvent):
        findings = self.radar.ingest(event)
        if not findings:
            return
        if not self.state.tools_permitted():          # already in an incident
            if self.incident:
                self.incident.suppressed += len(findings)
            self.log("RADAR", f"repeat anomaly while held (suppressed): {findings[0].message}")
            return
        self._open_incident(event, findings)

    def _open_incident(self, event, findings):
        self._n += 1
        f = findings[0]
        self.log("RADAR", f"anomaly: {f.message}")
        alert = self.canary.emit(f)
        iid = f"inc-{compact_now()}-{self._n:03d}"
        self.incident = Incident(iid, f"ff-{iid}", alert, event,
                                 suppressed=len(findings) - 1)
        self.log("CANARY", f"{alert.alert_id} severity={alert.severity} "
                           f"rule={alert.rule_id} authority_requested={alert.authority_requested}")
        self.state.enter_hold(f"canary {alert.alert_id}")
        self.log("HOLD", "tool execution blocked; telemetry stays observable")
        self._capture()

    def _capture(self):
        inc = self.incident
        try:
            self.state.begin_capture()
            self.log("FREEZE", f"capturing last {self.window} events (trigger last)")
            window = self.radar.window(self.window, inc.trigger.seq)
            inc.frame = ff.capture(
                frame_id=inc.frame_id, clock=self.clock, alert=inc.alert,
                trigger_event=inc.trigger, window_events=window, window_max=self.window,
                agent_id=self.agent_id, agent_state=self.state.agent.value,
                allowlist=self.allowlist,
                production_path=self.agent.path, timeline=self.state.history)
            inc.seal = ff.seal(inc.frame, self.evidence_dir, self.clock)
            inc.alert.evidence_ref = str(inc.seal.frame_dir)
            self.state.frame_sealed(f"sha256={inc.seal.sha256}")
            self.log("SEAL", f"sha256={inc.seal.sha256}")
        except Exception as exc:                      # fail closed
            inc.capture_error = repr(exc)
            self.state.capture_failed(f"capture failed: {exc!r}")
            self.log("SEAL", f"CAPTURE FAILED -> FAILED_CLOSED: {exc!r}")

    # ---- decision ------------------------------------------------------
    def decide(self, decision: Decision) -> DecisionOutcome:
        inc = self.incident
        if inc is None or self.state.agent not in (AgentState.HOLD, AgentState.FAILED_CLOSED):
            raise IllegalTransition("no held incident to decide on")
        if decision.choice == "ABORT":
            self.agent.stop()
            self.state.abort(f"{decision.decided_by}")
            out = DecisionOutcome("ABORTED", "agent loop stopped; evidence preserved, nothing deleted")
        elif decision.choice == "RESUME":
            out = self._try_resume(decision)
        else:
            raise ValueError(f"unknown decision {decision.choice!r}")
        inc.decisions.append({**decision.to_dict(), "result": out.outcome, "reason": out.reason})
        self.log("DECISION", f"{decision.choice} by {decision.decided_by} -> {out.outcome} ({out.reason})")
        return out

    def _try_resume(self, decision) -> DecisionOutcome:
        inc = self.incident
        if self.state.agent is not AgentState.HOLD:
            return DecisionOutcome("RESUME_REFUSED", "FAILED_CLOSED cannot be resumed")
        if self.state.frame is not FrameState.SEALED or inc.seal is None:
            return DecisionOutcome("RESUME_REFUSED", "no sealed Freeze-Frame")
        v = ff.verify(inc.seal.frame_dir, inc.seal.sha256)
        if not v.ok:
            self.state.capture_failed(f"seal verification failed: {v.reason}")
            return DecisionOutcome("RESUME_REFUSED", f"seal broken: {v.reason}; now FAILED_CLOSED")
        self.state.resume(decision.decided_by)
        return DecisionOutcome("RESUMED", "seal verified; tools re-enabled")

    def request_human_decision(self, input_fn=input, out=print) -> Optional[DecisionOutcome]:
        d = prompt_human(input_fn, out)
        if d is None:
            self.log("DECISION", "no decision received: remaining in HOLD (fail closed)")
            return None
        return self.decide(d)

    # ---- experiments ---------------------------------------------------
    def make_experiment_clone(self, label="scratch") -> Path:
        inc = self.incident
        if inc is None or inc.seal is None:
            raise IllegalTransition("no sealed frame to clone")
        v = ff.verify(inc.seal.frame_dir, inc.seal.sha256)
        if not v.ok:
            raise IllegalTransition(f"refusing to clone unverified evidence: {v.reason}")
        path = ff.clone_for_experiment(inc.seal.frame_dir, self.experiments_dir, label)
        inc.experiment = {"path": str(path)}
        return path

    # ---- record --------------------------------------------------------
    def finalize(self):
        inc = self.incident
        if inc is None or inc.record_path is not None:
            return None
        verified = "n/a (no sealed frame)"
        if inc.seal:
            v = ff.verify(inc.seal.frame_dir, inc.seal.sha256)
            verified = "OK" if v.ok else f"FAILED: {v.reason}"
        exp = None
        if inc.experiment:
            exp = dict(inc.experiment, canonical_unchanged=(verified == "OK"))
        prod = json.loads(self.agent.path.read_text())
        fields = (inc.frame or {}).get("fields", {})
        outcome = {AgentState.RESUMED: "RESUMED", AgentState.ABORTED: "ABORTED",
                   AgentState.FAILED_CLOSED: "FAILED_CLOSED",
                   AgentState.HOLD: "PENDING (no decision; still in HOLD)"}.get(
                       self.state.agent, self.state.agent.value)
        win = fields.get("telemetry_window", {}).get("value", {}).get("events", [])
        ctx = {
            "incident_id": inc.incident_id, "outcome": outcome,
            "alert": inc.alert.to_dict(), "suppressed": inc.suppressed,
            "decisions": inc.decisions,
            "production": {"path": str(self.agent.path),
                           "executed": len(prod["executed_tools"]),
                           "blocked": len(prod["blocked_attempts"]),
                           "bad_tool_executed": any(t["tool"] not in self.allowlist
                                                    for t in prod["executed_tools"])},
            "evidence": {"dir": str(inc.seal.frame_dir) if inc.seal else "none",
                         "sha256": inc.seal.sha256 if inc.seal else "none",
                         "verified": verified},
            "experiment": exp,
            "captured_fields": [k for k, v in fields.items() if v["status"] == "captured"],
            "unavailable_fields": [(k, v["reason"]) for k, v in fields.items()
                                   if v["status"] == "unavailable"],
            "window": win, "timeline": self.state.history,
        }
        inc.record_path, inc.record_hash = self.records.write(ctx)
        self.log("RECORD", f"{inc.record_path}")
        return inc.record_path, inc.record_hash
