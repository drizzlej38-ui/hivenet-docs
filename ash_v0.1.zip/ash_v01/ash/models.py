"""Plain data types for ASH v0.1. Serialisation only; no behaviour."""
from __future__ import annotations

import datetime as _dt
from dataclasses import asdict, dataclass
from typing import Any, Optional


def utc_now() -> str:
    return _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="milliseconds")


def compact_now() -> str:
    return _dt.datetime.now(_dt.timezone.utc).strftime("%Y%m%dT%H%M%S%f")[:-3] + "Z"


def captured(value: Any) -> dict:
    """A Freeze-Frame field we really captured."""
    return {"status": "captured", "value": value}


def unavailable(reason: str) -> dict:
    """A Freeze-Frame field v0.1 cannot capture. Say so; never fake it."""
    return {"status": "unavailable", "reason": reason}


@dataclass(frozen=True)
class TelemetryEvent:
    seq: int
    ts: str
    kind: str            # tool_attempt | tool_result
    tool: Optional[str]
    detail: str
    outcome: str = "observed"   # observed | executed | blocked

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class Finding:
    """What Dragon Radar says it saw. Not an alert yet."""
    rule_id: str
    severity: str
    observed: str
    threshold: str
    trigger_seq: int
    message: str


@dataclass
class CanaryAlert:
    """Standardised alert. Detection does not grant authority."""
    alert_id: str
    ts: str
    source: str
    rule_id: str
    severity: str
    observed: str
    threshold: str
    trigger_seq: int
    message: str
    evidence_ref: Optional[str] = None
    authority_requested: str = "none"

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class Decision:
    choice: str          # RESUME | ABORT
    decided_by: str      # human-cli | test-harness
    ts: str
    note: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class DecisionOutcome:
    outcome: str         # RESUMED | ABORTED | RESUME_REFUSED
    reason: str
