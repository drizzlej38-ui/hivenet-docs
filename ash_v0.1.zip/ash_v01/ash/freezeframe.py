"""Freeze-Frame: capture, seal (SHA-256), verify, clone.

Integrity here is TAMPER-EVIDENCE only. It is not authenticity: someone who can
rewrite frame.json AND manifest.json can forge both. That is why the controller
also holds the hash independently and the event record chain stores it too.
chmod 0444 is a speed bump, not a security boundary.
"""
from __future__ import annotations

import hashlib
import json
import os
import platform
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path

from .models import captured, unavailable

SCHEMA = "ash.freezeframe/0.1"


def canonical_bytes(obj) -> bytes:
    """Sorted keys, 2-space indent, UTF-8, trailing newline. We hash the bytes on disk."""
    return (json.dumps(obj, sort_keys=True, indent=2, ensure_ascii=False) + "\n").encode("utf-8")


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


@dataclass(frozen=True)
class SealResult:
    frame_dir: Path
    frame_path: Path
    manifest_path: Path
    sha256: str


@dataclass(frozen=True)
class VerifyResult:
    ok: bool
    reason: str


def capture(*, frame_id, clock, alert, trigger_event, window_events, window_max,
            agent_id, agent_state, allowlist, production_path, timeline) -> dict:
    prod = unavailable("no production state file found")
    p = Path(production_path)
    if p.exists():
        try:
            prod = captured(json.loads(p.read_text()))
        except Exception as exc:
            prod = unavailable(f"could not read production state: {exc}")
    no_model = "simulated agent has no model"
    return {
        "schema": SCHEMA,
        "frame_id": frame_id,
        "captured_at": clock(),
        "alert_id": alert.alert_id,
        "fields": {
            "agent_id": captured(agent_id),
            "agent_state_at_capture": captured(agent_state),
            "participating_agents": captured([agent_id]),
            "tools_and_permissions": captured({"allowlist": sorted(allowlist)}),
            "telemetry_window": captured({
                "max_events": window_max,
                "count": len(window_events),
                "trigger_seq": trigger_event.seq,
                "events": [e.to_dict() for e in window_events],   # trigger is last
            }),
            "event_timeline": captured(list(timeline)),
            "production_state_snapshot": prod,
            "environment": captured({"python": sys.version.split()[0],
                                     "platform": platform.platform()}),
            "model_version_hash": unavailable(no_model),
            "system_instructions": unavailable(no_model),
            "conversation_state": unavailable("simulated agent has no conversation"),
            "memory_state": unavailable("simulated agent has no memory store"),
            "agp_state": unavailable("AGP not implemented in v0.1"),
            "reproducibility": unavailable("not captured in v0.1"),
            "cryptographic_provenance": unavailable(
                "v0.1 is SHA-256 tamper-evidence only; unsigned"),
        },
    }


def seal(frame: dict, evidence_root, clock) -> SealResult:
    d = Path(evidence_root) / frame["frame_id"]
    d.mkdir(parents=True, exist_ok=False)          # never overwrite evidence
    data = canonical_bytes(frame)
    digest = sha256_hex(data)
    fp, mp = d / "frame.json", d / "manifest.json"
    with open(fp, "xb") as fh:
        fh.write(data)
    manifest = {"schema": "ash.manifest/0.1", "frame_id": frame["frame_id"],
                "file": "frame.json", "algorithm": "sha256", "sha256": digest,
                "size_bytes": len(data), "sealed_at": clock(),
                "signature": unavailable("unsigned in v0.1")}
    with open(mp, "xb") as fh:
        fh.write(canonical_bytes(manifest))
    os.chmod(fp, 0o444)
    os.chmod(mp, 0o444)
    return SealResult(d, fp, mp, digest)


def verify(frame_dir, expected_sha256=None) -> VerifyResult:
    d = Path(frame_dir)
    try:
        manifest = json.loads((d / "manifest.json").read_bytes())
        data = (d / "frame.json").read_bytes()
    except Exception as exc:
        return VerifyResult(False, f"unreadable evidence: {exc}")
    actual = sha256_hex(data)
    if actual != manifest.get("sha256"):
        return VerifyResult(False, "frame.json hash does not match manifest")
    if expected_sha256 and actual != expected_sha256:
        return VerifyResult(False, "hash does not match independently held hash")
    return VerifyResult(True, "sha256 matches")


def clone_for_experiment(frame_dir, experiments_root, label) -> Path:
    src = Path(frame_dir) / "frame.json"
    fid = json.loads(src.read_bytes())["frame_id"]
    dest = Path(experiments_root) / f"{fid}-{label}"
    dest.mkdir(parents=True, exist_ok=False)
    shutil.copyfile(src, dest / "frame.json")
    os.chmod(dest / "frame.json", 0o644)
    (dest / "EXPERIMENTAL.txt").write_text(
        "EXPERIMENTAL CLONE. Not evidence. Safe to modify. Canonical frame lives in evidence/.\n")
    return dest


def mutate_clone(clone_dir, key="experiment_note", value="modified by experiment") -> None:
    p = Path(clone_dir) / "frame.json"
    obj = json.loads(p.read_bytes())
    obj[key] = value
    p.write_bytes(canonical_bytes(obj))
