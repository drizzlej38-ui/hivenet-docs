"""State machine. Agent state and Freeze-Frame state are kept separate."""
from __future__ import annotations

from enum import Enum

from .models import utc_now


class AgentState(str, Enum):
    NORMAL = "NORMAL"
    HOLD = "HOLD"
    RESUMED = "RESUMED"
    ABORTED = "ABORTED"
    FAILED_CLOSED = "FAILED_CLOSED"


class FrameState(str, Enum):
    NOT_CAPTURED = "NOT_CAPTURED"
    CAPTURING = "CAPTURING"
    SEALED = "SEALED"
    INVALID = "INVALID"


class IllegalTransition(Exception):
    pass


A, F = AgentState, FrameState
_AGENT = {
    A.NORMAL: {A.HOLD},
    A.HOLD: {A.RESUMED, A.ABORTED, A.FAILED_CLOSED},
    A.RESUMED: {A.HOLD},
    A.ABORTED: set(),
    A.FAILED_CLOSED: {A.ABORTED},   # a human may stop it; it can never resume
}
_FRAME = {
    F.NOT_CAPTURED: {F.CAPTURING},
    F.CAPTURING: {F.SEALED, F.INVALID},
    F.SEALED: {F.INVALID},
    F.INVALID: set(),
}


class SystemState:
    def __init__(self, clock=utc_now):
        self._clock = clock
        self.agent = A.NORMAL
        self.frame = F.NOT_CAPTURED
        self.history: list[dict] = []

    # -- helpers -----------------------------------------------------
    def _log(self, kind, old, new, reason):
        self.history.append({"ts": self._clock(), "machine": kind,
                             "from": old.value, "to": new.value, "reason": reason})

    def _agent_to(self, new, reason):
        if new not in _AGENT[self.agent]:
            raise IllegalTransition(f"agent {self.agent.value} -> {new.value} not allowed")
        self._log("agent", self.agent, new, reason)
        self.agent = new

    def _frame_to(self, new, reason):
        if new not in _FRAME[self.frame]:
            raise IllegalTransition(f"frame {self.frame.value} -> {new.value} not allowed")
        self._log("frame", self.frame, new, reason)
        self.frame = new

    # -- queries -----------------------------------------------------
    def tools_permitted(self) -> bool:
        return self.agent in (A.NORMAL, A.RESUMED)

    def combined(self) -> str:
        if self.frame is F.NOT_CAPTURED:
            return self.agent.value
        return f"{self.agent.value}/{self.frame.value}"

    # -- transitions -------------------------------------------------
    def enter_hold(self, reason):
        self._agent_to(A.HOLD, reason)
        if self.frame is not F.NOT_CAPTURED:      # new incident, fresh frame lifecycle
            self._log("frame", self.frame, F.NOT_CAPTURED, "new incident")
            self.frame = F.NOT_CAPTURED

    def begin_capture(self, reason="capture started"):
        if self.agent is not A.HOLD:
            raise IllegalTransition("capture only allowed while in HOLD")
        self._frame_to(F.CAPTURING, reason)

    def frame_sealed(self, reason="sealed"):
        self._frame_to(F.SEALED, reason)

    def capture_failed(self, reason):
        """Fail closed: evidence unusable -> agent stays blocked."""
        if self.frame in (F.CAPTURING, F.SEALED):
            self._frame_to(F.INVALID, reason)
        if self.agent is A.HOLD:
            self._agent_to(A.FAILED_CLOSED, reason)

    def resume(self, reason="human decision"):
        if self.agent is not A.HOLD or self.frame is not F.SEALED:
            raise IllegalTransition("RESUME needs HOLD + SEALED frame")
        self._agent_to(A.RESUMED, reason)

    def abort(self, reason="human decision"):
        self._agent_to(A.ABORTED, reason)
