"""Watchable end-to-end run:  python -m ash.demo   (see --help)"""
from __future__ import annotations

import argparse
import sys
import time

from . import freezeframe as ff
from .controller import AshController
from .models import Decision, utc_now
from .state import AgentState

NORMAL = [("read_file", "open notes/readme.md"), ("search_notes", "query: project status"),
          ("summarize", "summarize 3 notes"), ("list_dir", "list notes/")]


def build_script(pre=24, post_hold=3, post_decision=2):
    s = [(NORMAL[i % 4][0], f"{NORMAL[i % 4][1]} (#{i + 1})") for i in range(pre)]
    s.append(("shell_exec", "SIMULATED privilege escalation: request for shell_exec"))
    s += [("read_file", f"post-trigger read (#{i + 1})") for i in range(post_hold)]
    s += [("summarize", f"post-decision work (#{i + 1})") for i in range(post_decision)]
    return s


def main(argv=None):
    ap = argparse.ArgumentParser(description="ASH v0.1 demo")
    ap.add_argument("--root", default="data")
    ap.add_argument("--decision", choices=["ask", "resume", "abort", "none"], default="ask",
                    help="ask = interactive human; resume/abort = test harness; none = leave in HOLD")
    ap.add_argument("--tamper", action="store_true", help="corrupt canonical frame before decision")
    ap.add_argument("--clone", action="store_true", help="make + modify an experimental clone")
    ap.add_argument("--window", type=int, default=20)
    ap.add_argument("--pace", type=float, default=0.25, help="seconds between stages")
    a = ap.parse_args(argv)

    def log(stage, msg):
        print(f"[{utc_now()[11:23]}] {stage:<9} {msg}", flush=True)
        time.sleep(a.pace)

    c = AshController(a.root, build_script(), window=a.window, log=log)
    log("NORMAL", f"agent running; allowlist={list(c.allowlist)}")

    while c.agent.has_steps and c.state.agent is AgentState.NORMAL:
        c.agent.step()
        if c.state.agent is AgentState.NORMAL:
            e = c.agent.executed[-1]
            if e["seq"] % 8 == 1:
                log("NORMAL", f"step ok: {e['tool']}")
    if c.incident is None:
        log("NORMAL", "no anomaly; script finished")
        return 0

    print(f"\n  state: {c.state.combined()}\n")
    for _ in range(3):                                # telemetry continues, tools blocked
        if c.agent.has_steps:
            c.agent.step()
            log("HOLD", f"agent still emitting telemetry; last action blocked "
                        f"({c.agent.blocked[-1]['tool']})")

    inc = c.incident
    if a.clone and inc.seal:
        p = c.make_experiment_clone()
        ff.mutate_clone(p)
        log("EXPERIMENT", f"clone modified at {p}")
    if a.tamper and inc.seal:
        import os
        os.chmod(inc.seal.frame_path, 0o644)
        inc.seal.frame_path.write_bytes(inc.seal.frame_path.read_bytes() + b" ")
        log("TAMPER", "canonical frame.json altered (test)")

    print()
    if a.decision == "ask":
        c.request_human_decision()
    elif a.decision in ("resume", "abort"):
        c.decide(Decision(a.decision.upper(), "test-harness (--decision flag)", utc_now()))
    else:
        log("DECISION", "no decision (--decision none): remaining in HOLD")

    if c.state.agent is AgentState.RESUMED:
        while c.agent.has_steps:
            c.agent.step()
            log("RESUMED", f"agent working again: {c.agent.executed[-1]['tool']}")

    res = c.finalize()
    ok, problems = c.records.verify_chain()
    print(f"\n  final state : {c.state.combined()}")
    print(f"  evidence    : {inc.seal.frame_dir if inc.seal else 'none'}")
    print(f"  record      : {res[0] if res else 'none'}")
    print(f"  record sha  : {res[1] if res else 'none'}")
    print(f"  chain       : {'OK' if ok else 'BROKEN ' + str(problems)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
