"""Dragon Radar: deterministic rules over telemetry. Detects; never acts."""
from __future__ import annotations

from collections import deque
from typing import Optional

from .models import Finding, TelemetryEvent


class ToolAllowlistRule:
    """Fires when the agent attempts a tool outside its allowlist
    (stands in for simulated privilege escalation / tool-use anomaly)."""
    rule_id = "tool-allowlist"

    def __init__(self, allowlist):
        self.allowlist = frozenset(allowlist)

    def evaluate(self, event: TelemetryEvent, history) -> Optional[Finding]:
        if event.kind == "tool_attempt" and event.tool not in self.allowlist:
            return Finding(self.rule_id, "high", f"tool={event.tool}",
                           f"allowlist={sorted(self.allowlist)}", event.seq,
                           f"tool '{event.tool}' is not on the allowlist")
        return None


class DragonRadar:
    def __init__(self, rules, max_history=500):
        self.rules = list(rules)
        self.history: deque[TelemetryEvent] = deque(maxlen=max_history)

    def ingest(self, event: TelemetryEvent) -> list[Finding]:
        self.history.append(event)
        out = []
        for rule in self.rules:
            f = rule.evaluate(event, self.history)
            if f:
                out.append(f)
        return out

    def window(self, max_events: int, upto_seq: int) -> list[TelemetryEvent]:
        """Last max_events events up to and including upto_seq. Never padded."""
        evs = [e for e in self.history if e.seq <= upto_seq]
        return evs[-max_events:]
