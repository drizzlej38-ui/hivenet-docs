"""Human-readable Markdown event record + simple hash chain.

Plain text is auditable by a human. It does NOT make the content safe from
prompt injection: telemetry text is untrusted data and is escaped, nothing more.
"""
from __future__ import annotations

import os
import re
from pathlib import Path

from .freezeframe import sha256_hex
from .models import utc_now

GENESIS = "GENESIS"
_PREV_RE = re.compile(r"prev_record_hash:\s*`([^`]+)`")


def _cell(s) -> str:
    return str(s).replace("|", "\\|").replace("\n", " ").replace("\r", " ").replace("`", "'")


def render(ctx: dict, prev_hash: str) -> str:
    a, inc = ctx["alert"], ctx
    L = []
    L.append(f"# ASH Event Record: {ctx['incident_id']}\n")
    L.append(f"- outcome: **{ctx['outcome']}**")
    L.append(f"- written_at: {ctx['written_at']}")
    L.append(f"- prev_record_hash: `{prev_hash}`\n")

    L.append("## 1. Canary alert\n")
    L.append("| field | value |\n|---|---|")
    for k in ("alert_id", "ts", "source", "rule_id", "severity", "observed",
              "threshold", "trigger_seq", "message", "evidence_ref", "authority_requested"):
        L.append(f"| {k} | {_cell(a.get(k))} |")
    L.append(f"\nFurther findings suppressed while already in HOLD: {ctx['suppressed']}\n")

    L.append("## 2. Decisions\n")
    if not ctx["decisions"]:
        L.append("No decision recorded. System remained in HOLD (fail closed).\n")
    else:
        L.append("| choice | decided_by | ts | result | reason |\n|---|---|---|---|---|")
        for d in ctx["decisions"]:
            L.append(f"| {d['choice']} | {d['decided_by']} | {d['ts']} | {d['result']} | {_cell(d['reason'])} |")
        L.append("")

    L.append("## 3. State separation\n")
    L.append("| category | location | status |\n|---|---|---|")
    p = ctx["production"]
    L.append(f"| Production state | `{p['path']}` | executed={p['executed']}, blocked={p['blocked']}, "
             f"unauthorised tool executed: {p['bad_tool_executed']} |")
    e = ctx["evidence"]
    L.append(f"| Canonical evidence | `{e['dir']}` | sha256 `{e['sha256']}`; verified at record time: {e['verified']} |")
    x = ctx["experiment"]
    if x:
        L.append(f"| Experimental state | `{x['path']}` | clone only; canonical unchanged: {x['canonical_unchanged']} |")
    else:
        L.append("| Experimental state | none | no clone made |")
    L.append(f"| Event / immune-memory record | `{ctx['record_name']}` | this file; chained by prev_record_hash |\n")

    L.append("## 4. Freeze-Frame contents\n")
    L.append("Captured: " + (", ".join(ctx["captured_fields"]) or "none"))
    L.append("\nUnavailable in v0.1 (not captured, not faked):\n")
    for name, why in ctx["unavailable_fields"]:
        L.append(f"- {name}: {_cell(why)}")
    L.append("")

    L.append("## 5. Telemetry window (trigger is the last row)\n")
    L.append("| seq | ts | kind | tool | outcome | detail |\n|---|---|---|---|---|---|")
    for ev in ctx["window"]:
        mark = " **TRIGGER**" if ev["seq"] == a["trigger_seq"] else ""
        L.append(f"| {ev['seq']} | {ev['ts']} | {ev['kind']} | {_cell(ev['tool'])} | "
                 f"{ev['outcome']} | {_cell(ev['detail'])}{mark} |")
    L.append("")

    L.append("## 6. State timeline\n")
    L.append("| ts | machine | from | to | reason |\n|---|---|---|---|---|")
    for h in ctx["timeline"]:
        L.append(f"| {h['ts']} | {h['machine']} | {h['from']} | {h['to']} | {_cell(h['reason'])} |")
    L.append("")

    L.append("## 7. Limits of this record\n")
    L.append("- Integrity is SHA-256 tamper-evidence only. Nothing is signed (v0.1).")
    L.append("- Markdown is human-auditable. It does not prevent prompt injection; "
             "telemetry text above is untrusted data.")
    L.append("- HOLD state is in memory only. A process restart does not restore it.")
    return "\n".join(L) + "\n"


class RecordWriter:
    def __init__(self, events_dir):
        self.dir = Path(events_dir)
        self.dir.mkdir(parents=True, exist_ok=True)
        self.chain = self.dir / "chain.txt"

    def last_hash(self) -> str:
        if not self.chain.exists():
            return GENESIS
        lines = [l for l in self.chain.read_text().splitlines() if l.strip()]
        return lines[-1].split()[0] if lines else GENESIS

    def write(self, ctx: dict):
        prev = self.last_hash()
        name = f"{ctx['incident_id']}.md"
        ctx = dict(ctx, record_name=name, written_at=utc_now())
        data = render(ctx, prev).encode("utf-8")
        path = self.dir / name
        with open(path, "xb") as fh:
            fh.write(data)
        digest = sha256_hex(data)
        with open(self.chain, "a") as fh:
            fh.write(f"{digest}  {name}\n")
        os.chmod(path, 0o444)
        return path, digest

    def verify_chain(self):
        problems, prev = [], GENESIS
        if not self.chain.exists():
            return True, problems
        for line in self.chain.read_text().splitlines():
            if not line.strip():
                continue
            digest, name = line.split(None, 1)
            f = self.dir / name.strip()
            if not f.exists():
                problems.append(f"{name}: missing")
                continue
            data = f.read_bytes()
            if sha256_hex(data) != digest:
                problems.append(f"{name}: hash mismatch")
            m = _PREV_RE.search(data.decode("utf-8", "replace"))
            if not m or m.group(1) != prev:
                problems.append(f"{name}: prev_record_hash broken")
            prev = digest
        return not problems, problems
