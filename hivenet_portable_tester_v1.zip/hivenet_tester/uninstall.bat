@echo off
title HiveNet - Uninstaller
color 0C

echo.
echo ============================================================
echo    HIVENET NODE TESTER - UNINSTALLER
echo ============================================================
echo.
echo This will remove all HiveNet files from this device.
echo.
set /p CONFIRM="Are you sure? (y/n): "
if /i not "%CONFIRM%"=="y" (
    echo Cancelled.
    pause
    exit /b 0
)

echo.
echo Removing HiveNet files...

REM Run the Python uninstaller if Python is available
python --version >nul 2>&1
if %errorlevel% equ 0 (
    python hivenet_node_tester.py --uninstall
)

REM Remove report files
del /f /q hivenet_report_*.txt 2>nul
del /f /q hivenet_report_*.json 2>nul
del /f /q hivenet_log_*.json 2>nul
del /f /q hivenet_node_tester.py 2>nul
del /f /q hivenet_controller.py 2>nul
del /f /q install_and_run.bat 2>nul
del /f /q README.txt 2>nul

echo.
echo [OK] All HiveNet files removed.
echo [OK] Device is completely clean.
echo.
echo You can now delete this uninstall.bat file.
echo.
pause

REM Self-delete this bat file last
(goto) 2>nul & del /f /q "%~f0"
