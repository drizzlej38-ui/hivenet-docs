╔══════════════════════════════════════════════════════════════╗
║           HIVENET PORTABLE NODE TESTER v1.0                  ║
║                    README / INSTRUCTIONS                     ║
╚══════════════════════════════════════════════════════════════╝

WHAT THIS IS:
  Tests any device's capability to be a HiveNet mesh node.
  Measures CPU, memory, temperature, network, and performance.
  Reports results back to your tablet automatically over the network.
  Leaves NO trace after uninstall.

═══════════════════════════════════════════════════════════════
  STEP 1: START THE CONTROLLER ON YOUR TABLET (do this first)
═══════════════════════════════════════════════════════════════

  In Termux on your tablet:
    python hivenet_controller.py

  It will show your tablet's IP address. Write it down.
  Example: "Your tablet IP: 192.168.1.105"
  Leave this running while you test other devices.

═══════════════════════════════════════════════════════════════
  STEP 2A: WINDOWS (mom's laptop)
═══════════════════════════════════════════════════════════════

  Option A - Double-click method (easiest):
    1. Copy these files to any folder on the laptop:
       - hivenet_node_tester.py
       - install_and_run.bat
       - uninstall.bat
    2. Double-click install_and_run.bat
    3. Enter your tablet's IP when asked
    4. Test runs automatically
    5. When done, type 'y' to uninstall immediately

  Option B - Command line:
    python hivenet_node_tester.py --parent 192.168.1.105 --duration 10

  To uninstall separately:
    Double-click uninstall.bat
    OR: python hivenet_node_tester.py --uninstall

═══════════════════════════════════════════════════════════════
  STEP 2B: ANDROID / TERMUX
═══════════════════════════════════════════════════════════════

  1. Copy hivenet_node_tester.py to Termux
  2. Run:
     python hivenet_node_tester.py --parent 192.168.1.105

  To uninstall:
     python hivenet_node_tester.py --uninstall
     rm hivenet_node_tester.py

═══════════════════════════════════════════════════════════════
  STEP 2C: MAC / LINUX
═══════════════════════════════════════════════════════════════

  1. Copy hivenet_node_tester.py to any folder
  2. Run:
     python3 hivenet_node_tester.py --parent 192.168.1.105

  To uninstall:
     python3 hivenet_node_tester.py --uninstall
     rm hivenet_node_tester.py

═══════════════════════════════════════════════════════════════
  COMMAND OPTIONS
═══════════════════════════════════════════════════════════════

  hivenet_node_tester.py [options]

  --parent IP    IP of your tablet (results sent there)
  --port N       Port number (default: 7700)
  --duration N   Test length in minutes (default: 10)
  --uninstall    Remove all traces from this device

  Examples:
    python hivenet_node_tester.py --parent 192.168.1.105
    python hivenet_node_tester.py --parent 192.168.1.105 --duration 5
    python hivenet_node_tester.py --duration 20   (standalone, no parent)
    python hivenet_node_tester.py --uninstall

═══════════════════════════════════════════════════════════════
  VIEWING RESULTS ON YOUR TABLET
═══════════════════════════════════════════════════════════════

  Results are saved in: hivenet_results/ folder

  View all collected results:
    python hivenet_controller.py --summary

  Each device gets its own JSON file with full data.

═══════════════════════════════════════════════════════════════
  WHAT GETS MEASURED
═══════════════════════════════════════════════════════════════

  Device Profile:
    - OS type and version
    - CPU model, cores, speed
    - RAM (total and available)
    - Storage free space
    - Network type (WiFi / Ethernet / Cellular)
    - Battery level and charge status
    - All temperature sensors

  Performance Test:
    - Phase 1: Warm-up tasks (simple prime calc)
    - Phase 2: Standard tasks (moderate prime calc)
    - Phase 3: Heavy tasks (complex prime calc)
    - Logs every 10 seconds: CPU%, memory%, temperature
    - Detects: thermal throttling, performance degradation,
               memory issues, errors

  Node Rating (Bad / Worse / Good / Great / Peak):
    Based on: success rate, temperature, performance stability

═══════════════════════════════════════════════════════════════
  SAFETY
═══════════════════════════════════════════════════════════════

  ⚠️  Test automatically stops if temperature exceeds 60°C
  ✓  Default 50% CPU reserved (won't max out the device)
  ✓  Can stop anytime with Ctrl+C
  ✓  No network connections except to YOUR tablet's IP

═══════════════════════════════════════════════════════════════
  WHAT GETS LEFT ON THE DEVICE AFTER UNINSTALL
═══════════════════════════════════════════════════════════════

  NOTHING. Uninstall removes:
    - hivenet_node_tester.py (the script)
    - All report files (hivenet_report_*.txt, *.json)
    - psutil library (if we installed it)
    - The .bat files (Windows only)

  The device will be exactly as it was before.

═══════════════════════════════════════════════════════════════
  FILES IN THIS PACKAGE
═══════════════════════════════════════════════════════════════

  hivenet_node_tester.py   - Main tester (runs on any device)
  hivenet_controller.py    - Runs on YOUR tablet to collect results
  install_and_run.bat      - Windows: double-click to install+run
  uninstall.bat            - Windows: double-click to remove everything
  README.txt               - This file

═══════════════════════════════════════════════════════════════
  PROJECT: HIVENET / OMNIVOICE  |  Tester v1.0
═══════════════════════════════════════════════════════════════
