#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════╗
║           HIVENET PORTABLE NODE TESTER v1.0                  ║
║   Runs on: Windows / Mac / Linux / Android (Termux)          ║
║   Tests device capability + reports to parent device         ║
║   Leaves NO trace after uninstall                            ║
╚══════════════════════════════════════════════════════════════╝

Usage:
  python hivenet_node_tester.py              - Run standalone test
  python hivenet_node_tester.py --parent 192.168.1.100  - Report to parent
  python hivenet_node_tester.py --parent 192.168.1.100 --port 7700
  python hivenet_node_tester.py --duration 10           - 10 minute test
  python hivenet_node_tester.py --uninstall             - Remove all traces
"""

import os
import sys
import time
import json
import socket
import platform
import threading
import argparse
import subprocess
from datetime import datetime
from pathlib import Path

# ─────────────────────────────────────────────
# AUTO-INSTALL DEPENDENCIES
# ─────────────────────────────────────────────

def install_if_missing(package, import_name=None):
    """Install a package if not available, cross-platform"""
    import_name = import_name or package
    try:
        __import__(import_name)
        return True
    except ImportError:
        print(f"  Installing {package}...")
        try:
            # Termux / system Python
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install",
                 "--break-system-packages", "--quiet", package],
                capture_output=True, timeout=60
            )
            if result.returncode != 0:
                # Try without --break-system-packages (Windows/Mac)
                subprocess.run(
                    [sys.executable, "-m", "pip", "install", "--quiet", package],
                    capture_output=True, timeout=60
                )
            __import__(import_name)
            return True
        except Exception as e:
            print(f"  Could not install {package}: {e}")
            return False

print("╔══════════════════════════════════════════════════════════╗")
print("║          HIVENET PORTABLE NODE TESTER v1.0               ║")
print("╚══════════════════════════════════════════════════════════╝")
print("\nChecking dependencies...")
install_if_missing("psutil")

try:
    import psutil
    PSUTIL_OK = True
except:
    PSUTIL_OK = False
    print("  WARNING: psutil unavailable - hardware stats limited")

# ─────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────

VERSION = "1.0"
DEFAULT_PARENT_PORT = 7700
TEMP_WARNING = 45.0
TEMP_CRITICAL = 60.0
LOG_INTERVAL = 10  # seconds between periodic logs

# ─────────────────────────────────────────────
# DEVICE PROFILER
# ─────────────────────────────────────────────

class DeviceProfiler:
    """Gather comprehensive device information"""

    def __init__(self):
        self.os_type = platform.system()
        self.is_android = self._detect_android()
        self.is_termux = self._detect_termux()

    def _detect_android(self):
        try:
            return os.path.exists("/system/build.prop") or \
                   "android" in platform.platform().lower() or \
                   self.is_termux
        except:
            return False

    def _detect_termux(self):
        return os.path.exists("/data/data/com.termux") or \
               "com.termux" in os.environ.get("PREFIX", "") or \
               os.path.exists("/data/data/com.termux/files/usr")

    def get_device_type(self):
        if self.is_android:
            return "Android/Mobile"
        elif self.os_type == "Windows":
            return "Windows PC"
        elif self.os_type == "Darwin":
            return "Mac"
        elif self.os_type == "Linux":
            return "Linux"
        return "Unknown"

    def get_cpu_info(self):
        info = {
            "model": platform.processor() or "Unknown",
            "cores_physical": None,
            "cores_logical": None,
            "frequency_mhz": None,
            "architecture": platform.machine()
        }
        if PSUTIL_OK:
            try:
                info["cores_physical"] = psutil.cpu_count(logical=False)
                info["cores_logical"] = psutil.cpu_count(logical=True)
                freq = psutil.cpu_freq()
                if freq:
                    info["frequency_mhz"] = round(freq.current, 1)
            except:
                pass
        return info

    def get_memory_info(self):
        info = {"total_mb": None, "available_mb": None, "percent_used": None}
        if PSUTIL_OK:
            try:
                mem = psutil.virtual_memory()
                info["total_mb"] = round(mem.total / (1024*1024), 1)
                info["available_mb"] = round(mem.available / (1024*1024), 1)
                info["percent_used"] = mem.percent
            except:
                pass
        return info

    def get_storage_info(self):
        info = {"free_gb": None, "total_gb": None}
        if PSUTIL_OK:
            try:
                disk = psutil.disk_usage('/')
                info["free_gb"] = round(disk.free / (1024**3), 2)
                info["total_gb"] = round(disk.total / (1024**3), 2)
            except:
                pass
        return info

    def get_network_info(self):
        info = {
            "connection_type": "Unknown",
            "hostname": socket.gethostname(),
            "local_ip": None,
            "interfaces": []
        }
        try:
            # Get local IP
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            info["local_ip"] = s.getsockname()[0]
            s.close()
        except:
            pass

        if PSUTIL_OK:
            try:
                net_if = psutil.net_if_addrs()
                net_stats = psutil.net_if_stats()
                for iface, addrs in net_if.items():
                    if iface == "lo":
                        continue
                    stats = net_stats.get(iface)
                    if stats and stats.isup:
                        iface_info = {
                            "name": iface,
                            "speed_mbps": stats.speed if stats.speed > 0 else None,
                            "is_up": stats.isup
                        }
                        for addr in addrs:
                            if addr.family == socket.AF_INET:
                                iface_info["ip"] = addr.address
                        info["interfaces"].append(iface_info)

                        # Guess connection type
                        name_lower = iface.lower()
                        if any(x in name_lower for x in ["wlan", "wifi", "wl", "wlp"]):
                            info["connection_type"] = "WiFi"
                        elif any(x in name_lower for x in ["eth", "en0", "en1", "enp"]):
                            info["connection_type"] = "Ethernet"
                        elif any(x in name_lower for x in ["rmnet", "ccmni", "wwan"]):
                            info["connection_type"] = "Cellular"
                        elif any(x in name_lower for x in ["usb", "rndis"]):
                            info["connection_type"] = "USB Tethering"
            except:
                pass

        return info

    def get_battery_info(self):
        info = {"percent": None, "plugged_in": None, "seconds_left": None}
        if PSUTIL_OK:
            try:
                batt = psutil.sensors_battery()
                if batt:
                    info["percent"] = round(batt.percent, 1)
                    info["plugged_in"] = batt.power_plugged
                    if batt.secsleft and batt.secsleft > 0:
                        info["seconds_left"] = batt.secsleft
            except:
                pass
        return info

    def get_temperature(self):
        """Get temperature readings from all available sensors"""
        temps = {}
        if PSUTIL_OK:
            try:
                sensor_data = psutil.sensors_temperatures()
                if sensor_data:
                    for sensor_name, readings in sensor_data.items():
                        for reading in readings:
                            key = f"{sensor_name}"
                            if reading.label:
                                key += f"_{reading.label}"
                            temps[key] = round(reading.current, 1)
            except:
                pass

        # Android-specific temperature reading
        if self.is_android and not temps:
            thermal_paths = [
                "/sys/class/thermal/thermal_zone0/temp",
                "/sys/class/thermal/thermal_zone1/temp",
                "/sys/devices/virtual/thermal/thermal_zone0/temp"
            ]
            for i, path in enumerate(thermal_paths):
                try:
                    with open(path) as f:
                        raw = int(f.read().strip())
                        temp = raw / 1000.0 if raw > 1000 else float(raw)
                        temps[f"thermal_zone{i}"] = round(temp, 1)
                except:
                    pass

        return temps

    def get_primary_temp(self):
        """Get single best temperature reading"""
        temps = self.get_temperature()
        if not temps:
            return None
        # Prefer CPU temp
        for key in temps:
            if "cpu" in key.lower() or "core" in key.lower():
                return temps[key]
        # Return first available
        return list(temps.values())[0]

    def get_full_profile(self):
        """Complete device snapshot"""
        return {
            "timestamp": datetime.now().isoformat(),
            "device_type": self.get_device_type(),
            "os": {
                "system": self.os_type,
                "version": platform.version(),
                "release": platform.release(),
                "is_android": self.is_android,
                "is_termux": self.is_termux
            },
            "cpu": self.get_cpu_info(),
            "memory": self.get_memory_info(),
            "storage": self.get_storage_info(),
            "network": self.get_network_info(),
            "battery": self.get_battery_info(),
            "temperatures": self.get_temperature(),
            "python_version": platform.python_version(),
            "hostname": socket.gethostname()
        }

# ─────────────────────────────────────────────
# PERFORMANCE TESTER
# ─────────────────────────────────────────────

class PerformanceTester:
    """Run compute tasks and measure performance"""

    def __init__(self, profiler):
        self.profiler = profiler
        self.results = []
        self.periodic_logs = []
        self.running = False
        self.thermal_events = []

    def calculate_primes(self, limit):
        """Prime calculation - standard HiveNet task"""
        primes = []
        for num in range(2, limit + 1):
            is_prime = True
            for i in range(2, int(num ** 0.5) + 1):
                if num % i == 0:
                    is_prime = False
                    break
            if is_prime:
                primes.append(num)
        return len(primes)

    def get_current_stats(self):
        """Quick stats snapshot"""
        stats = {
            "timestamp": datetime.now().isoformat(),
            "cpu_percent": None,
            "memory_percent": None,
            "temperature": None
        }
        if PSUTIL_OK:
            try:
                stats["cpu_percent"] = psutil.cpu_percent(interval=0.1)
                stats["memory_percent"] = psutil.virtual_memory().percent
                stats["temperature"] = self.profiler.get_primary_temp()
            except:
                pass
        return stats

    def periodic_logger(self, stop_event):
        """Background thread: log system state every N seconds"""
        while not stop_event.is_set():
            log_entry = self.get_current_stats()
            self.periodic_logs.append(log_entry)

            # Check thermal events
            temp = log_entry.get("temperature")
            if temp:
                if temp >= TEMP_CRITICAL:
                    self.thermal_events.append({
                        "time": log_entry["timestamp"],
                        "temp": temp,
                        "level": "CRITICAL"
                    })
                    print(f"\n  🔥 CRITICAL TEMP: {temp}°C - stopping test!")
                    stop_event.set()
                    return
                elif temp >= TEMP_WARNING:
                    self.thermal_events.append({
                        "time": log_entry["timestamp"],
                        "temp": temp,
                        "level": "WARNING"
                    })
                    print(f"\n  ⚠️  Temp warning: {temp}°C")

            stop_event.wait(LOG_INTERVAL)

    def run_task(self, task_type, task_num):
        """Run a single task and record results"""
        limits = {
            "simple": 1000,
            "standard": 10000,
            "complex": 50000
        }
        limit = limits.get(task_type, 1000)

        start_stats = self.get_current_stats()
        start_time = time.time()

        try:
            result_count = self.calculate_primes(limit)
            status = "completed"
            error = None
        except Exception as e:
            result_count = 0
            status = "failed"
            error = str(e)

        duration = time.time() - start_time
        end_stats = self.get_current_stats()

        result = {
            "task_num": task_num,
            "task_type": task_type,
            "status": status,
            "duration_sec": round(duration, 3),
            "result_count": result_count,
            "error": error,
            "start_cpu": start_stats.get("cpu_percent"),
            "end_cpu": end_stats.get("cpu_percent"),
            "start_memory": start_stats.get("memory_percent"),
            "end_memory": end_stats.get("memory_percent"),
            "start_temp": start_stats.get("temperature"),
            "end_temp": end_stats.get("temperature"),
            "clock_time": start_stats["timestamp"]
        }

        self.results.append(result)
        return result

    def run_test_suite(self, duration_minutes=10):
        """
        Adaptive test suite that fits within available time.
        Scales complexity to duration.
        """
        print(f"\n{'─'*60}")
        print(f"  Starting test suite ({duration_minutes} min available)")
        print(f"{'─'*60}")

        stop_event = threading.Event()
        log_thread = threading.Thread(
            target=self.periodic_logger,
            args=(stop_event,),
            daemon=True
        )
        log_thread.start()

        self.running = True
        end_time = time.time() + (duration_minutes * 60)
        task_num = 0

        # Phase 1: Warm-up (simple tasks, first 20% of time)
        phase1_end = time.time() + (duration_minutes * 60 * 0.2)
        print(f"\n  Phase 1: Warm-up (simple tasks)")
        while time.time() < phase1_end and not stop_event.is_set():
            task_num += 1
            r = self.run_task("simple", task_num)
            status_char = "✓" if r["status"] == "completed" else "✗"
            temp_str = f" {r['end_temp']}°C" if r['end_temp'] else ""
            print(f"    Task {task_num:3d} {status_char} {r['duration_sec']:.2f}s"
                  f"  CPU:{r['end_cpu']}%{temp_str}")

        # Phase 2: Standard load (middle 50% of time)
        phase2_end = time.time() + (duration_minutes * 60 * 0.5)
        print(f"\n  Phase 2: Standard load")
        while time.time() < phase2_end and not stop_event.is_set():
            task_num += 1
            r = self.run_task("standard", task_num)
            status_char = "✓" if r["status"] == "completed" else "✗"
            temp_str = f" {r['end_temp']}°C" if r['end_temp'] else ""
            print(f"    Task {task_num:3d} {status_char} {r['duration_sec']:.2f}s"
                  f"  CPU:{r['end_cpu']}%{temp_str}")

        # Phase 3: Heavy load (last 30% of time, if time permits and temp OK)
        if not stop_event.is_set():
            print(f"\n  Phase 3: Heavy load")
            while time.time() < end_time and not stop_event.is_set():
                task_num += 1
                r = self.run_task("complex", task_num)
                status_char = "✓" if r["status"] == "completed" else "✗"
                temp_str = f" {r['end_temp']}°C" if r['end_temp'] else ""
                print(f"    Task {task_num:3d} {status_char} {r['duration_sec']:.2f}s"
                      f"  CPU:{r['end_cpu']}%{temp_str}")

        stop_event.set()
        log_thread.join(timeout=5)
        self.running = False

        print(f"\n  Test suite complete. {task_num} tasks run.")
        return self.results

# ─────────────────────────────────────────────
# REPORT GENERATOR
# ─────────────────────────────────────────────

class ReportGenerator:
    """Generate human-readable and machine-readable reports"""

    def __init__(self, profile, tester):
        self.profile = profile
        self.tester = tester

    def get_node_rating(self):
        """Rate this device as a HiveNet node"""
        results = self.tester.results
        if not results:
            return "UNTESTED", "No test data available"

        completed = [r for r in results if r["status"] == "completed"]
        if not completed:
            return "FAILED", "No tasks completed successfully"

        success_rate = len(completed) / len(results) * 100
        avg_duration_standard = None

        std_tasks = [r for r in completed if r["task_type"] == "standard"]
        if std_tasks:
            avg_duration_standard = sum(r["duration_sec"] for r in std_tasks) / len(std_tasks)

        # Check thermal issues
        max_temp = None
        temps = [r["end_temp"] for r in completed if r["end_temp"]]
        if temps:
            max_temp = max(temps)

        # Performance degradation check
        degradation = 0
        if len(completed) >= 10:
            first = completed[:5]
            last = completed[-5:]
            avg_first = sum(r["duration_sec"] for r in first) / len(first)
            avg_last = sum(r["duration_sec"] for r in last) / len(last)
            degradation = ((avg_last - avg_first) / avg_first) * 100

        # Rating logic
        issues = []
        if success_rate < 90:
            issues.append(f"Low success rate ({success_rate:.0f}%)")
        if max_temp and max_temp > TEMP_CRITICAL:
            issues.append(f"Critical temperature ({max_temp}°C)")
        elif max_temp and max_temp > TEMP_WARNING:
            issues.append(f"Elevated temperature ({max_temp}°C)")
        if degradation > 20:
            issues.append(f"Performance degradation ({degradation:+.0f}%)")

        if not issues and success_rate >= 98:
            if avg_duration_standard and avg_duration_standard < 2.0:
                return "PEAK", "Excellent performance, no issues detected"
            return "GREAT", "Strong performance, no issues detected"
        elif len(issues) == 0:
            return "GOOD", "Acceptable performance"
        elif len(issues) == 1:
            return "WORSE", f"Minor issues: {issues[0]}"
        else:
            return "BAD", f"Multiple issues: {'; '.join(issues)}"

    def generate_summary(self):
        """Generate human-readable summary"""
        results = self.tester.results
        completed = [r for r in results if r["status"] == "completed"]
        failed = [r for r in results if r["status"] == "failed"]
        rating, rating_reason = self.get_node_rating()

        net = self.profile.get("network", {})
        cpu = self.profile.get("cpu", {})
        mem = self.profile.get("memory", {})
        batt = self.profile.get("battery", {})
        temps = self.profile.get("temperatures", {})

        lines = []
        lines.append("╔══════════════════════════════════════════════════════════╗")
        lines.append("║           HIVENET NODE TEST REPORT                       ║")
        lines.append("╚══════════════════════════════════════════════════════════╝")
        lines.append(f"  Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"  Hostname:  {self.profile.get('hostname', 'Unknown')}")
        lines.append(f"  Device:    {self.profile.get('device_type', 'Unknown')}")
        lines.append("")

        lines.append("── DEVICE PROFILE ──────────────────────────────────────────")
        lines.append(f"  OS:          {self.profile['os']['system']} "
                     f"{self.profile['os']['release']}")
        lines.append(f"  CPU:         {cpu.get('model', 'Unknown')}")
        lines.append(f"  Cores:       {cpu.get('cores_physical', '?')} physical / "
                     f"{cpu.get('cores_logical', '?')} logical")
        lines.append(f"  CPU Speed:   {cpu.get('frequency_mhz', '?')} MHz")
        lines.append(f"  Architecture:{cpu.get('architecture', '?')}")
        lines.append(f"  RAM Total:   {mem.get('total_mb', '?')} MB")
        lines.append(f"  RAM Free:    {mem.get('available_mb', '?')} MB")
        lines.append(f"  Storage Free:{self.profile.get('storage', {}).get('free_gb', '?')} GB")

        if batt.get("percent") is not None:
            plugged = "Yes" if batt.get("plugged_in") else "No"
            lines.append(f"  Battery:     {batt['percent']}% (Plugged: {plugged})")
            if batt.get("seconds_left") and not batt.get("plugged_in"):
                mins = batt["seconds_left"] // 60
                lines.append(f"  Batt. Left:  ~{mins} minutes")

        lines.append("")
        lines.append("── NETWORK ──────────────────────────────────────────────────")
        lines.append(f"  Connection:  {net.get('connection_type', 'Unknown')}")
        lines.append(f"  Local IP:    {net.get('local_ip', 'Unknown')}")
        for iface in net.get("interfaces", []):
            speed = f"{iface['speed_mbps']} Mbps" if iface.get('speed_mbps') else "speed unknown"
            lines.append(f"  Interface:   {iface['name']} ({speed})")

        if temps:
            lines.append("")
            lines.append("── TEMPERATURES (at start) ──────────────────────────────────")
            for sensor, temp in temps.items():
                flag = " ⚠️" if temp > TEMP_WARNING else ""
                flag = " 🔥" if temp > TEMP_CRITICAL else flag
                lines.append(f"  {sensor}: {temp}°C{flag}")

        lines.append("")
        lines.append("── TEST RESULTS ─────────────────────────────────────────────")
        lines.append(f"  Total tasks:     {len(results)}")
        lines.append(f"  Completed:       {len(completed)} "
                     f"({len(completed)/max(len(results),1)*100:.1f}%)")
        lines.append(f"  Failed:          {len(failed)}")

        if completed:
            durations = [r["duration_sec"] for r in completed]
            cpu_vals = [r["end_cpu"] for r in completed if r["end_cpu"]]
            mem_vals = [r["end_memory"] for r in completed if r["end_memory"]]
            temp_vals = [r["end_temp"] for r in completed if r["end_temp"]]

            lines.append("")
            lines.append("── PERFORMANCE ──────────────────────────────────────────────")
            lines.append(f"  Avg duration:    {sum(durations)/len(durations):.3f}s")
            lines.append(f"  Min duration:    {min(durations):.3f}s")
            lines.append(f"  Max duration:    {max(durations):.3f}s")

            # Stability: first vs last 5 tasks
            if len(completed) >= 10:
                avg_first = sum(r["duration_sec"] for r in completed[:5]) / 5
                avg_last = sum(r["duration_sec"] for r in completed[-5:]) / 5
                change = ((avg_last - avg_first) / avg_first) * 100
                stability = "Stable ✓" if abs(change) < 10 else f"Degraded {change:+.1f}% ⚠️"
                lines.append(f"  Stability:       {stability}")

            if cpu_vals:
                lines.append(f"  Avg CPU load:    {sum(cpu_vals)/len(cpu_vals):.1f}%")
                lines.append(f"  Peak CPU load:   {max(cpu_vals):.1f}%")
            if mem_vals:
                lines.append(f"  Avg memory use:  {sum(mem_vals)/len(mem_vals):.1f}%")
                lines.append(f"  Peak memory use: {max(mem_vals):.1f}%")
            if temp_vals:
                lines.append(f"  Avg temperature: {sum(temp_vals)/len(temp_vals):.1f}°C")
                lines.append(f"  Peak temperature:{max(temp_vals):.1f}°C")

        if self.tester.thermal_events:
            lines.append("")
            lines.append("── THERMAL EVENTS ───────────────────────────────────────────")
            for evt in self.tester.thermal_events:
                lines.append(f"  [{evt['level']}] {evt['time']}: {evt['temp']}°C")

        lines.append("")
        lines.append("── NODE RATING ──────────────────────────────────────────────")
        rating_bars = {
            "PEAK": "████████████ PEAK",
            "GREAT": "██████████░░ GREAT",
            "GOOD": "████████░░░░ GOOD",
            "WORSE": "█████░░░░░░░ WORSE",
            "BAD": "███░░░░░░░░░ BAD",
            "FAILED": "░░░░░░░░░░░░ FAILED",
            "UNTESTED": "░░░░░░░░░░░░ UNTESTED"
        }
        lines.append(f"  {rating_bars.get(rating, rating)}")
        lines.append(f"  Reason: {rating_reason}")

        lines.append("")
        lines.append("── HIVENET SUITABILITY ──────────────────────────────────────")
        sandbox_note = "MANDATORY (mobile OS enforces it)" if \
            self.profile.get("os", {}).get("is_android") else \
            "RECOMMENDED (user data present)"
        lines.append(f"  Sandboxing:      {sandbox_note}")
        lines.append(f"  Connection type: {net.get('connection_type', 'Unknown')}")

        if net.get("connection_type") == "WiFi":
            lines.append(f"  Network note:    WiFi - suitable for LAN mesh testing")
        elif net.get("connection_type") == "Cellular":
            lines.append(f"  Network note:    Cellular - limited LAN mesh, good for relay")
        elif net.get("connection_type") == "Ethernet":
            lines.append(f"  Network note:    Ethernet - excellent for mesh, low latency")

        lines.append("")
        lines.append("═"*62)

        return "\n".join(lines)

    def generate_json_log(self):
        """Full machine-readable log"""
        return {
            "report_version": VERSION,
            "generated": datetime.now().isoformat(),
            "device_profile": self.profile,
            "test_results": self.tester.results,
            "periodic_logs": self.tester.periodic_logs,
            "thermal_events": self.tester.thermal_events,
            "node_rating": self.get_node_rating()[0],
            "node_rating_reason": self.get_node_rating()[1]
        }

# ─────────────────────────────────────────────
# PARENT REPORTER - sends results over network
# ─────────────────────────────────────────────

class ParentReporter:
    """Send results back to parent/controller device"""

    def __init__(self, parent_ip, parent_port=DEFAULT_PARENT_PORT):
        self.parent_ip = parent_ip
        self.parent_port = parent_port

    def send_report(self, report_data):
        """Send JSON report to parent device"""
        try:
            payload = json.dumps(report_data).encode("utf-8")
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(30)
            sock.connect((self.parent_ip, self.parent_port))
            # Send length first, then data
            length = len(payload)
            sock.sendall(length.to_bytes(8, byteorder='big'))
            sock.sendall(payload)
            # Wait for ACK
            ack = sock.recv(3)
            sock.close()
            if ack == b"ACK":
                print(f"\n  ✓ Report sent to parent device ({self.parent_ip}:{self.parent_port})")
                return True
            else:
                print(f"\n  ⚠️  Parent responded unexpectedly")
                return False
        except Exception as e:
            print(f"\n  ✗ Could not reach parent: {e}")
            print(f"    Save the local report file instead.")
            return False

# ─────────────────────────────────────────────
# UNINSTALLER
# ─────────────────────────────────────────────

def uninstall():
    """Remove all traces of the tester from this device"""
    print("\n╔══════════════════════════════════════════════════════════╗")
    print("║                    UNINSTALLING                          ║")
    print("╚══════════════════════════════════════════════════════════╝")

    script_dir = Path(__file__).parent
    files_to_remove = [
        "hivenet_node_tester.py",
        "hivenet_report_*.txt",
        "hivenet_report_*.json",
        "hivenet_log_*.json"
    ]

    removed = []
    for pattern in files_to_remove:
        for f in script_dir.glob(pattern):
            try:
                f.unlink()
                removed.append(str(f.name))
            except Exception as e:
                print(f"  Could not remove {f.name}: {e}")

    if removed:
        print(f"\n  Removed {len(removed)} files:")
        for f in removed:
            print(f"    ✓ {f}")
    else:
        print("  No files found to remove.")

    # Try to remove pip packages that were auto-installed
    print("\n  Removing auto-installed packages...")
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "uninstall", "-y", "psutil"],
            capture_output=True
        )
        print("  ✓ psutil removed")
    except:
        print("  (psutil may not have been installed by us - skipping)")

    print("\n  ✓ Uninstall complete. Device is clean.")
    print("  You can now delete this script file manually.\n")

# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="HiveNet Portable Node Tester"
    )
    parser.add_argument("--parent", type=str,
                        help="IP address of parent/controller device")
    parser.add_argument("--port", type=int, default=DEFAULT_PARENT_PORT,
                        help=f"Parent device port (default: {DEFAULT_PARENT_PORT})")
    parser.add_argument("--duration", type=int, default=10,
                        help="Test duration in minutes (default: 10)")
    parser.add_argument("--uninstall", action="store_true",
                        help="Remove all traces from this device")
    args = parser.parse_args()

    if args.uninstall:
        uninstall()
        return

    # ── STEP 1: Profile the device ──
    print("\n  Profiling device...")
    profiler = DeviceProfiler()
    profile = profiler.get_full_profile()

    print(f"  Device type:  {profile['device_type']}")
    print(f"  OS:           {profile['os']['system']} {profile['os']['release']}")
    print(f"  CPU cores:    {profile['cpu'].get('cores_logical', '?')} logical")
    print(f"  RAM:          {profile['memory'].get('total_mb', '?')} MB total")
    print(f"  Network:      {profile['network'].get('connection_type', 'Unknown')}")
    print(f"  Local IP:     {profile['network'].get('local_ip', 'Unknown')}")

    batt = profile.get("battery", {})
    if batt.get("percent") is not None:
        plugged = "plugged in" if batt.get("plugged_in") else "on battery"
        print(f"  Battery:      {batt['percent']}% ({plugged})")

    start_temps = profile.get("temperatures", {})
    if start_temps:
        for sensor, temp in start_temps.items():
            flag = " ⚠️ WARM" if temp > TEMP_WARNING else ""
            print(f"  Temp ({sensor}): {temp}°C{flag}")

    # ── STEP 2: Run tests ──
    print(f"\n  Test duration: {args.duration} minutes")
    if args.parent:
        print(f"  Reporting to: {args.parent}:{args.port}")

    tester = PerformanceTester(profiler)
    tester.run_test_suite(duration_minutes=args.duration)

    # ── STEP 3: Generate reports ──
    print("\n  Generating reports...")
    reporter = ReportGenerator(profile, tester)

    summary_text = reporter.generate_summary()
    json_log = reporter.generate_json_log()

    # Save locally
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    hostname = socket.gethostname().replace(" ", "_")

    txt_filename = f"hivenet_report_{hostname}_{timestamp}.txt"
    json_filename = f"hivenet_report_{hostname}_{timestamp}.json"

    script_dir = Path(__file__).parent

    with open(script_dir / txt_filename, "w") as f:
        f.write(summary_text)

    with open(script_dir / json_filename, "w") as f:
        json.dump(json_log, f, indent=2, default=str)

    print(f"\n  Reports saved:")
    print(f"    {txt_filename}  (human readable)")
    print(f"    {json_filename} (full log)")

    # ── STEP 4: Print summary ──
    print("\n" + summary_text)

    # ── STEP 5: Send to parent if specified ──
    if args.parent:
        sender = ParentReporter(args.parent, args.port)
        sent = sender.send_report(json_log)
        if not sent:
            print(f"\n  Tip: Copy {txt_filename} manually to your tablet.")

    print("\n  To uninstall: python hivenet_node_tester.py --uninstall")
    print("  Then delete this script file.\n")

if __name__ == "__main__":
    main()
