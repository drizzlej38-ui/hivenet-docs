#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════╗
║         HIVENET TEST CONTROLLER (Parent Device)              ║
║   Runs on YOUR TABLET - collects results from all nodes      ║
║   Displays live incoming results + saves everything          ║
╚══════════════════════════════════════════════════════════════╝

Usage:
  python hivenet_controller.py              - Listen on default port
  python hivenet_controller.py --port 7700  - Custom port
  python hivenet_controller.py --summary    - Show all collected results

Run this FIRST on your tablet before running tester on other devices.
It will show your tablet's IP address to use with --parent flag.
"""

import os
import sys
import json
import socket
import threading
import argparse
from datetime import datetime
from pathlib import Path

CONTROLLER_PORT = 7700
RESULTS_DIR = Path("hivenet_results")

def get_local_ip():
    """Get this device's IP on the local network"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "Unable to detect IP"

def format_rating_bar(rating):
    bars = {
        "PEAK":    "████████████ PEAK",
        "GREAT":   "██████████░░ GREAT",
        "GOOD":    "████████░░░░ GOOD",
        "WORSE":   "█████░░░░░░░ WORSE",
        "BAD":     "███░░░░░░░░░ BAD",
        "FAILED":  "░░░░░░░░░░░░ FAILED",
        "UNTESTED":"░░░░░░░░░░░░ UNTESTED"
    }
    return bars.get(rating, rating)

def display_incoming_report(report):
    """Print a nicely formatted summary of an incoming report"""
    profile = report.get("device_profile", {})
    results = report.get("test_results", [])
    rating = report.get("node_rating", "UNKNOWN")
    reason = report.get("node_rating_reason", "")

    completed = [r for r in results if r.get("status") == "completed"]
    failed = [r for r in results if r.get("status") == "failed"]

    hostname = profile.get("hostname", "Unknown")
    device_type = profile.get("device_type", "Unknown")
    os_info = profile.get("os", {})
    network = profile.get("network", {})
    cpu = profile.get("cpu", {})
    mem = profile.get("memory", {})
    batt = profile.get("battery", {})

    print("\n" + "╔" + "═"*58 + "╗")
    print(f"║  📡 INCOMING REPORT: {hostname:<36}║")
    print("╚" + "═"*58 + "╝")
    print(f"  Device:     {device_type} | {os_info.get('system','')} {os_info.get('release','')}")
    print(f"  CPU:        {cpu.get('cores_logical','?')} cores @ {cpu.get('frequency_mhz','?')} MHz")
    print(f"  RAM:        {mem.get('total_mb','?')} MB total, {mem.get('available_mb','?')} MB free")
    print(f"  Network:    {network.get('connection_type','?')} | IP: {network.get('local_ip','?')}")

    if batt.get("percent") is not None:
        plugged = "⚡ plugged" if batt.get("plugged_in") else "🔋 battery"
        print(f"  Battery:    {batt['percent']}% ({plugged})")

    # Temperature at start
    start_temps = profile.get("temperatures", {})
    if start_temps:
        temp_str = ", ".join(f"{k}: {v}°C" for k,v in list(start_temps.items())[:3])
        print(f"  Start temp: {temp_str}")

    print(f"\n  Tasks run:  {len(results)} | ✓ {len(completed)} success | ✗ {len(failed)} failed")

    if completed:
        durations = [r["duration_sec"] for r in completed]
        avg_dur = sum(durations) / len(durations)
        print(f"  Avg task:   {avg_dur:.3f}s")

        temp_vals = [r["end_temp"] for r in completed if r.get("end_temp")]
        if temp_vals:
            print(f"  Peak temp:  {max(temp_vals):.1f}°C")

        cpu_vals = [r["end_cpu"] for r in completed if r.get("end_cpu")]
        if cpu_vals:
            print(f"  Peak CPU:   {max(cpu_vals):.1f}%")

    thermal = report.get("thermal_events", [])
    if thermal:
        print(f"\n  ⚠️  Thermal events: {len(thermal)}")
        for evt in thermal[:3]:
            print(f"     [{evt['level']}] {evt['temp']}°C at {evt['time']}")

    print(f"\n  Node Rating: {format_rating_bar(rating)}")
    print(f"  Reason:      {reason}")
    print("─" * 60)

def handle_connection(conn, addr, results_dir):
    """Handle an incoming connection from a test node"""
    try:
        # Receive length header
        raw_len = b""
        while len(raw_len) < 8:
            chunk = conn.recv(8 - len(raw_len))
            if not chunk:
                return
            raw_len += chunk

        data_length = int.from_bytes(raw_len, byteorder='big')
        print(f"\n  📨 Receiving report from {addr[0]} ({data_length} bytes)...")

        # Receive full payload
        data = b""
        while len(data) < data_length:
            chunk = conn.recv(min(65536, data_length - len(data)))
            if not chunk:
                break
            data += chunk

        # Send ACK
        conn.sendall(b"ACK")
        conn.close()

        # Parse and save
        report = json.loads(data.decode("utf-8"))

        # Save full JSON
        hostname = report.get("device_profile", {}).get("hostname", "unknown")
        hostname = hostname.replace(" ", "_").replace("/", "_")
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = results_dir / f"node_{hostname}_{addr[0]}_{timestamp}.json"

        with open(filename, "w") as f:
            json.dump(report, f, indent=2, default=str)

        # Display summary
        display_incoming_report(report)
        print(f"  💾 Saved: {filename.name}")

    except json.JSONDecodeError as e:
        print(f"  ✗ Invalid report from {addr[0]}: {e}")
    except Exception as e:
        print(f"  ✗ Error handling connection from {addr[0]}: {e}")
    finally:
        try:
            conn.close()
        except:
            pass

def show_all_results(results_dir):
    """Display summary of all collected results"""
    files = sorted(results_dir.glob("node_*.json"))
    if not files:
        print("  No results collected yet.")
        return

    print(f"\n{'═'*62}")
    print(f"  COLLECTED RESULTS ({len(files)} devices tested)")
    print(f"{'═'*62}")

    ratings_count = {}
    all_devices = []

    for f in files:
        try:
            with open(f) as fp:
                report = json.load(fp)

            profile = report.get("device_profile", {})
            rating = report.get("node_rating", "UNKNOWN")
            results = report.get("test_results", [])
            completed = [r for r in results if r.get("status") == "completed"]

            hostname = profile.get("hostname", "Unknown")
            device_type = profile.get("device_type", "Unknown")
            network = profile.get("network", {})
            avg_dur = None
            if completed:
                durations = [r["duration_sec"] for r in completed]
                avg_dur = sum(durations) / len(durations)

            ratings_count[rating] = ratings_count.get(rating, 0) + 1
            all_devices.append({
                "hostname": hostname,
                "type": device_type,
                "connection": network.get("connection_type", "?"),
                "rating": rating,
                "tasks": len(results),
                "success": len(completed),
                "avg_duration": avg_dur,
                "file": f.name
            })

            rating_bar = format_rating_bar(rating)
            avg_str = f"{avg_dur:.2f}s avg" if avg_dur else "no data"
            print(f"\n  {hostname} ({device_type})")
            print(f"    {rating_bar}")
            print(f"    {len(completed)}/{len(results)} tasks | {avg_str} | "
                  f"{network.get('connection_type','?')}")

        except Exception as e:
            print(f"  Error reading {f.name}: {e}")

    print(f"\n{'─'*62}")
    print(f"  NETWORK RATING SUMMARY:")
    total = sum(ratings_count.values())
    for rating in ["PEAK", "GREAT", "GOOD", "WORSE", "BAD", "FAILED"]:
        if rating in ratings_count:
            count = ratings_count[rating]
            bar = "█" * count + "░" * (total - count)
            print(f"    {rating:<8}: {bar} ({count})")

    print(f"\n  Total devices tested: {total}")
    capable = sum(ratings_count.get(r, 0) for r in ["PEAK", "GREAT", "GOOD"])
    print(f"  HiveNet capable:      {capable}/{total}")
    print(f"{'═'*62}\n")

def run_listener(port, results_dir):
    """Main listener loop"""
    results_dir.mkdir(exist_ok=True)

    local_ip = get_local_ip()

    print(f"\n{'═'*62}")
    print(f"  HIVENET TEST CONTROLLER RUNNING")
    print(f"{'═'*62}")
    print(f"  Your tablet IP:  {local_ip}")
    print(f"  Listening on:    port {port}")
    print(f"  Results saved:   ./{results_dir}/")
    print(f"\n  On test devices, run:")
    print(f"  python hivenet_node_tester.py --parent {local_ip}")
    print(f"\n  Press Ctrl+C to stop and see summary")
    print(f"{'─'*62}")

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("0.0.0.0", port))
    server.listen(10)
    server.settimeout(1.0)

    try:
        while True:
            try:
                conn, addr = server.accept()
                print(f"\n  📡 Connection from {addr[0]}:{addr[1]}")
                t = threading.Thread(
                    target=handle_connection,
                    args=(conn, addr, results_dir),
                    daemon=True
                )
                t.start()
            except socket.timeout:
                continue
    except KeyboardInterrupt:
        print(f"\n\n  Shutting down controller...")
        server.close()
        print(f"\n  Final Results:")
        show_all_results(results_dir)

def main():
    parser = argparse.ArgumentParser(
        description="HiveNet Test Controller - runs on parent/tablet device"
    )
    parser.add_argument("--port", type=int, default=CONTROLLER_PORT,
                        help=f"Port to listen on (default: {CONTROLLER_PORT})")
    parser.add_argument("--summary", action="store_true",
                        help="Show all collected results and exit")
    args = parser.parse_args()

    if args.summary:
        show_all_results(RESULTS_DIR)
        return

    run_listener(args.port, RESULTS_DIR)

if __name__ == "__main__":
    main()
