@echo off
title HiveNet Node Tester - Windows Installer
color 0A

echo.
echo ============================================================
echo    HIVENET PORTABLE NODE TESTER - WINDOWS SETUP
echo ============================================================
echo.

REM ── Check Python ──
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] Python not found. Attempting to install via winget...
    winget install Python.Python.3.12 --silent --accept-package-agreements
    if %errorlevel% neq 0 (
        echo.
        echo [!] Auto-install failed. Please install Python manually:
        echo     https://www.python.org/downloads/
        echo     Make sure to check "Add Python to PATH"
        pause
        exit /b 1
    )
    echo [OK] Python installed.
) else (
    echo [OK] Python found.
)

REM ── Install psutil ──
echo [..] Installing psutil...
python -m pip install --quiet psutil
echo [OK] Dependencies ready.

REM ── Ask for parent IP ──
echo.
set /p PARENT_IP="Enter your tablet's IP address (or press Enter to run standalone): "
set /p DURATION="Test duration in minutes [default 10]: "
if "%DURATION%"=="" set DURATION=10

echo.
echo ============================================================
echo    STARTING TEST  (Duration: %DURATION% minutes)
echo ============================================================
echo.

if "%PARENT_IP%"=="" (
    python hivenet_node_tester.py --duration %DURATION%
) else (
    python hivenet_node_tester.py --parent %PARENT_IP% --duration %DURATION%
)

echo.
echo ============================================================
echo    TEST COMPLETE
echo ============================================================
echo.
echo Report files saved in this folder.
echo.
set /p UNINSTALL="Uninstall now? (y/n): "
if /i "%UNINSTALL%"=="y" (
    python hivenet_node_tester.py --uninstall
    echo.
    echo Deleting installer files...
    del /f /q install_and_run.bat 2>nul
    del /f /q uninstall.bat 2>nul
    echo.
    echo [OK] All HiveNet files removed. Device is clean.
)

pause
